#include "NodoGeneral.h"
#include <iostream>
#include <list>
#include <queue>
#include <stack>

template <class T>
NodoGeneral<T>::NodoGeneral()
{
    this->desc.clear();
}

template <class T>
NodoGeneral<T>::~NodoGeneral()
{
    typename std::list<NodoGeneral<T>* >::iterator it;
    for (it = this->desc.begin(); it != this->desc.end(); it++)
    {
        delete *it;
    }

    this->desc.clear();
}

template <class T>
T& NodoGeneral<T>::obtenerDato()
{
    return this->dato;
}

template <class T>
void NodoGeneral<T>::fijarDato(const T& val)
{
    this->dato = val;
}

template <class T>
void NodoGeneral<T>::LimpiarLista()
{
    this->desc.clear();
}

template <class T>
bool NodoGeneral<T>::adcionarDesc(T& nval)
{
  typename std::list<NodoGeneral<T>*>::iterator i;
  for(i = this->desc.begin();i!=this->desc.end();i++){
    if((*i)->obtenerDato()==nval){
      return false;
    }
  }
    NodoGeneral<T> *nodo = new NodoGeneral<T>;
    nodo->fijarDato(nval);
    this->desc.push_back(nodo);
  return true;
}

template <class T>
bool NodoGeneral<T>::eliminarDesc(T& val)
{
    bool eliminado = false;
    typename std::list<NodoGeneral<T>*>::iterator it;
    for (it = this->desc.begin(); it != this->desc.end();it++)
    {
        NodoGeneral<T>* aux = *it;

        // Si encontramos el nodo a eliminar
        if (aux->obtenerDato() == val)
        {
            // Eliminar este nodo y sus descendientes recursivamente
            delete aux;
            it = this->desc.erase(it);
            eliminado = true;
        }
        else
        {
            // Si no es el nodo a eliminar, seguir buscando en sus descendientes
            eliminado = aux->eliminarDesc(val);

            // Si se eliminó el nodo de los descendientes, salir del bucle
            if (eliminado)
                break;

            
        }
    }

    return eliminado;
}

template <class T>
bool NodoGeneral<T>::esHoja()
{
    return this->desc.size() == 0;
}

template <class T>
int NodoGeneral<T>::altura()
{
    int alt = -1;
    if (this->esHoja())
    {
        alt = 0;
    }
    else
    {
        int alth;
        typename std::list<NodoGeneral<T>* >::iterator it;
        for (it = this->desc.begin(); it != this->desc.end(); it++)
        {
            alth = (*it)->altura();
            if (alt < alth+1)
            {
                alt = alth+1;
            }
        }
    }
    return alt;
}

template <class T>
void NodoGeneral<T>::preOrden()
{
    typename std::list<NodoGeneral<T>* >::iterator it;
    std::cout << this->obtenerDato() << " ";
    for (it = this->desc.begin(); it != this->desc.end(); it++)
    {
        (*it)->preOrden();
    }
}

template <class T>
NodoGeneral<T>* NodoGeneral<T>::insertarNodo(T padre, T n)
{
    typename std::list<NodoGeneral<T>*>::iterator hijo;
    if (this->obtenerDato() == padre)
    {
        // Recorrer los hijos del nodo actual
        for (hijo = this->desc.begin(); hijo != this->desc.end(); ++hijo)
        {
            // Si el hijo actual tiene el mismo dato que n, retornar el hijo
            if ((*hijo)->obtenerDato() == n)
            {
                return *hijo;
            }
        }

        // Si no se encontró un hijo con el mismo dato que n, crear un nuevo hijo
        NodoGeneral<T>* nuevoHijo = new NodoGeneral<T>;
        nuevoHijo->fijarDato(n);
        this->desc.push_back(nuevoHijo);
        return nuevoHijo;
    }

    // Si el nodo actual no es el padre, buscar en los hijos
    for (hijo = this->desc.begin(); hijo != this->desc.end(); ++hijo)
    {
        NodoGeneral<T>* nodoInsertado = (*hijo)->insertarNodo(padre, n);
        if (nodoInsertado != nullptr)
        {
            return nodoInsertado;
        }
    }

    return nullptr;
}


template <class T>
bool NodoGeneral<T>::buscar(T n)
    
{
    typename std::list<NodoGeneral<T>*>::iterator it;
     // Si el nodo actual es el que estamos buscando, retornar true
    if (this->obtenerDato() == n)
    {
        return true;
    }

    // Si no, buscar en cada nodo hijo
    for (it = this->desc.begin(); it != this->desc.end(); ++it)
    {
        if ((*it)->buscar(n))
        {
            return true;
        }
    }

    // Si no se encontró el nodo en este subárbol, retornar false
    return false;
}

template <class T>
int NodoGeneral<T>::tamano()
{
    int tam = 1;
    typename std::list<NodoGeneral<T>*>::iterator it;
    for (it = this->desc.begin(); it != this->desc.end(); it++)
    {
        tam += (*it)->tamano();
    }
    return tam;
}

template <class T>
void NodoGeneral<T>::postOrden()
{
    typename std::list<NodoGeneral<T>*>::iterator it;
    for (it = this->desc.begin(); it != this->desc.end(); it++)
    {
        (*it)->postOrden();
    }
    std::cout << this->obtenerDato() << " ";
}

template <class T>
std::list<NodoGeneral<T>*> NodoGeneral<T>::obtenerDesc()
{
    return this->desc;
}

template <class T>
int NodoGeneral<T>::contarPalabras()
{
    int count = 0;
    if (this->esHoja())
    {
        count = 1;
    }
    else
    {
        typename std::list<NodoGeneral<T>*>::iterator it;
        for (it = this->desc.begin(); it != this->desc.end(); it++)
        {
            count += (*it)->contarPalabras();
        }
    }
    return count;
}
