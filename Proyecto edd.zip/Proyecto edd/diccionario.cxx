#include "diccionario.h"

bool Diccionario::palabraValida(const std::string& palabra, const std::vector<std::string>& diccionario) {
    for (const std::string& p : diccionario) {
        if (p == palabra) {
            return true;
        }
    }
    return false;
}