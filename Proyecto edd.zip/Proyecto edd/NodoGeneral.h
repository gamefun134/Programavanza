#ifndef __NODOGENERAL_H__
#define __NODOGENERAL_H__

#include <list>

template <class T>
class NodoGeneral
{
    protected:
        T dato;
        std::list<NodoGeneral<T>*> desc;
    public:
    NodoGeneral();
    ~NodoGeneral();
    T& obtenerDato();
    void fijarDato(const T& val);
    void LimpiarLista();
    std::list<NodoGeneral<T>*> obtenerDesc();
    bool adcionarDesc (T& nval);
    bool eliminarDesc (T& val);
    bool esHoja();
    int altura();
    void preOrden();
    NodoGeneral<T>* insertarNodo(T padre, T n);
    bool buscar(T n);
    int tamano();
    void postOrden();
    int contarPalabras();
};

#include "NodoGeneral.hxx"
#endif
