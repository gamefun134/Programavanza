#ifndef SISTEMA_H
#define SISTEMA_H

#include <string>
#include <vector>
#include "diccionario.h"
#include "ArbolGeneral.h"
class Sistema {
private:
    std::vector<std::string> diccionario_leer;
    std::vector<std::string> diccionarioInverso;
    Diccionario diccionario; 
    std::vector<ArbolGeneral<char>> arboles;
    std::vector<ArbolGeneral<char>> arbolesinverso;   
public:
    void inicializar(std::string archivo);
    void inicializarInverso(std::string archivo);
    void mostrarPuntajePalabra(const std::string& palabra);
    bool insertarArbol(const std::string& dato);
    bool pPrefijo(const std::string& prefijo);
    bool pSufijo(const std::string& sufijo);
    bool insArbolinverso(const std::string& dato);
    void buscarPorPrefijo(NodoGeneral<char>* nodo, const std::string& prefijo, std::string palabraActual, std::vector<std::string>& palabras);
    void buscarPorSufijo(NodoGeneral<char>* nodo, const std::string& sufijo, std::string palabraActual, std::vector<std::string>& palabras, std::vector<int>& longitudes, std::vector<int>& puntajes);
    void imprimirPalabras(NodoGeneral<char>* nodo, std::string palabraActual);
};
#endif // SISTEMA_H
