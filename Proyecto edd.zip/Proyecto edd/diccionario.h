#ifndef DICCIONARIO_H
#define DICCIONARIO_H

#include "palabra.h"
#include <vector>

class Diccionario {
private:
    std::vector<Palabra> palabras;
public:
    bool palabraValida(const std::string& palabra, const std::vector<std::string>& diccionario);
};

#endif // DICCIONARIO_H