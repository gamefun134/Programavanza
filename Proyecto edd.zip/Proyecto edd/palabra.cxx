#include "palabra.h"
#include <map>

int Palabra::calcularPuntaje() const {
    std::map<char, int> valores = {
        {'E', 1}, {'A', 1}, {'I', 1}, {'O', 1}, {'N', 1},
        {'R', 1}, {'T', 1}, {'L', 1}, {'S', 1}, {'U', 1},
        {'D', 2}, {'G', 2},
        {'B', 3}, {'C', 3}, {'M', 3}, {'P', 3},
        {'F', 4}, {'H', 4}, {'V', 4}, {'W', 4}, {'Y', 4},
        {'K', 5},
        {'J', 8}, {'X', 8},
        {'Q', 10}, {'Z', 10}
    };
    int puntaje = 0;
    for (char letra : palabra) {
        puntaje += valores[std::toupper(letra)]; // Utilizar std::toupper
    }
    return puntaje;

}
