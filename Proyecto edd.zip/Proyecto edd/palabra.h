#ifndef PALABRA_H
#define PALABRA_H

#include <string>

class Palabra {
private:
    std::string palabra;
public:
    Palabra(std::string palabra) : palabra(palabra) {}
    std::string getPalabra() const { return palabra; } // Cambiar getPalabra() para que sea const
    int calcularPuntaje() const; // Declarar la función calcularPuntaje() const
};
#endif // PALABRA_H