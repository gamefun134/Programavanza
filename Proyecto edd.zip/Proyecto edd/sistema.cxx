#include "sistema.h"
#include <fstream>
#include <iostream>
#include <cctype>
#include "diccionario.h"

void Sistema::inicializar(std::string archivo) {
    static int inicializar = 0;
    if (inicializar == 0) {
        std::ifstream file(archivo);
        if (!file) {
            std::cout << "El archivo " << archivo << " no existe o no puede ser leído.\n";
            return;
        }
        std::string palabra;
        while (file >> palabra) {
            // Convertir la palabra a minúsculas
            for (size_t i = 0; i < palabra.length(); ++i) {
                palabra[i] = std::tolower(palabra[i]);
            }

            // Verifica que la palabra no contenga símbolos inválidos
            bool esValida = true;
            for (size_t i = 0; i < palabra.length(); ++i) {
                if (!std::isalpha(palabra[i])) {
                    esValida = false;
                    break;
                }
            }
            // Si la palabra es válida, la agrega al diccionario
            if (esValida) {
                diccionario_leer.push_back(palabra);
            }
        }
        std::cout << "El diccionario se ha inicializado correctamente.\n";
        inicializar++;
    } else {
        std::cout << "El diccionario ya ha sido inicializado.\n";
    }
}

void Sistema::inicializarInverso(std::string archivo) {
    static int inicializar = 0;
    if (inicializar == 0) {
        std::ifstream file(archivo);
        if (!file) {
            std::cout << "El archivo " << archivo << " no existe o no puede ser leído.\n";
            return;
        }
        std::string palabra;
        while (file >> palabra) {
            // Convertir la palabra a minúsculas
            for (size_t i = 0; i < palabra.length(); ++i) {
                palabra[i] = std::tolower(palabra[i]);
            }

            // Verifica que la palabra no contenga símbolos inválidos
            bool esValida = true;
            for (size_t i = 0; i < palabra.length(); ++i) {
                if (!std::isalpha(palabra[i])) {
                    esValida = false;
                    break;
                }
            }

            // Si la palabra es válida, la invierte y la agrega al diccionario inverso
            if (esValida) {
                std::string palabraInversa = "";
                for (int i = palabra.length() - 1; i >= 0; --i) {
                    palabraInversa += palabra[i];
                }
                diccionarioInverso.push_back(palabraInversa);
            }
        }
        std::cout << "El diccionario inverso se ha inicializado correctamente.\n";
        inicializar++;
    } else {
        std::cout << "El diccionario inverso ya ha sido inicializado.\n";
    }
}

void Sistema::mostrarPuntajePalabra(const std::string& palabra) {
    bool contieneSoloLetras = true;
    for (size_t i = 0; i < palabra.length(); ++i) {
        if (!std::isalpha(palabra[i])) {
            contieneSoloLetras = false;
            break;
        }
    }

    if (!contieneSoloLetras) {
        std::cout << "La palabra contiene caracteres no válidos.\n";
        return;
    }

    if (diccionario_leer.empty() && diccionarioInverso.empty()) {
        std::cout << "Ningún diccionario ha sido inicializado. Por favor, inicialice al menos uno de los diccionarios antes de verificar el puntaje de la palabra.\n";
        return;
    }

    bool palabraValida = false;
    if (!diccionario_leer.empty()) {
        palabraValida = diccionario.palabraValida(palabra, diccionario_leer);
    }
    if (!palabraValida && !diccionarioInverso.empty()) {
        palabraValida = diccionario.palabraValida(palabra, diccionarioInverso);
    }

    if (palabraValida) {
        Palabra p(palabra);
        int puntaje = p.calcularPuntaje();
        std::cout << "La palabra tiene un puntaje de: " << puntaje << ".\n";
    } else {
        std::cout << "La palabra no existe en ninguno de los diccionarios.\n";
    }
}

bool Sistema::insertarArbol(const std::string& dato) {
    static int inicializar = 0;
    if (inicializar == 0) {
        // Crear un vector de árboles, cada posición representa una letra del alfabeto
        arboles.resize(26);

        // Abrir el archivo de texto
        std::ifstream archivo(dato);
        if (!archivo) {
            std::cerr << "El archivo " << dato << " no existe o no puede ser leído." << std::endl;
            return false;
        }

        // Leer y procesar cada palabra del archivo
        std::string palabra;
        while (archivo >> palabra) {
            // Convertir la palabra a minúsculas
            for (size_t i = 0; i < palabra.size(); ++i) {
                palabra[i] = std::tolower(palabra[i]);
            }

            // Verificar si la palabra contiene solo letras del alfabeto
            bool esValida = true;
            for (size_t i = 0; i < palabra.size(); ++i) {
                if (!std::isalpha(palabra[i])) {
                    esValida = false;
                    break;
                }
            }

            // Procesar solo si la palabra es válida
            if (esValida) {
                // Obtener la primera letra de la palabra
                char primeraLetra = palabra[0];

                // Calcular el índice correspondiente en el vector de árboles
                int indice = primeraLetra - 'a';

                // Si el árbol correspondiente no existe, crear uno nuevo con la letra como raíz
                if (arboles[indice].esVacio()) {
                    NodoGeneral<char>* newRoot = new NodoGeneral<char>;
                    newRoot->fijarDato(primeraLetra);
                    arboles[indice].fijarRaiz(newRoot);
                }

                // Agregar la palabra al árbol correspondiente
                char letraPadre = primeraLetra;
                NodoGeneral<char>* nodoPadre = arboles[indice].obtenerRaiz();
                for (size_t i = 1; i < palabra.size(); ++i) {
                    char letra = palabra[i];
                    nodoPadre = nodoPadre->insertarNodo(letraPadre, letra);
                    letraPadre = letra;
                }

                // Insertar el carácter '?' al final de la palabra
                nodoPadre->insertarNodo(letraPadre, '?');
            } else {
                std::cerr << "La palabra \"" << palabra << "\" contiene caracteres no válidos y no será insertada." << std::endl;
            }
        }

        // Cerrar el archivo
        archivo.close();
        std::cout << "El Arbol de diccionario se ha inicializado correctamente.\n";
        inicializar++;
        std::cout << "Las palabras en el árbol son:\n";
        for (size_t i = 0; i < arboles.size(); ++i) {
            imprimirPalabras(arboles[i].obtenerRaiz(), "");
        }
        for (auto& arbol : arboles) {
        std::cout << "Recorrido preOrden del árbol: ";
        arbol.preOrden();
        std::cout << std::endl;
    }
        return true;
    } else {
        std::cout << "El arbol ya ha sido inicializado.\n";
        return false;
    }
}

bool Sistema::pPrefijo(const std::string& prefijo) {
    std::vector<std::string> palabrasConPrefijo;

    // Recorre cada árbol en 'arboles'
    for (auto& arbol : arboles) {
        if (!arbol.esVacio()) {
            NodoGeneral<char>* raiz = arbol.obtenerRaiz();
            buscarPorPrefijo(raiz, prefijo, "", palabrasConPrefijo);
        }
    }

    if (palabrasConPrefijo.empty()) {
        std::cout << "Prefijo " << prefijo << " no pudo encontrarse en el diccionario." << std::endl;
        return false;
    }

    // Imprime las palabras que comienzan con el prefijo, su tamaño y su puntaje
    std::cout << "Palabras que comienzan con '" << prefijo << "':" << std::endl;
    for (const auto& palabra : palabrasConPrefijo) {
        Palabra p(palabra); // Creamos un objeto Palabra con la palabra actual
        int puntaje = p.calcularPuntaje(); // Calculamos el puntaje de la palabra
        int longitud = palabra.length(); // Obtenemos la longitud de la palabra
        std::cout << palabra << " - Longitud: " << longitud << " - Puntaje: " << puntaje << std::endl;
    }

    return true;
}




void Sistema::buscarPorPrefijo(NodoGeneral<char>* nodo, const std::string& prefijo, std::string palabraActual, std::vector<std::string>& palabras) {
    if (!nodo) return;

    palabraActual += nodo->obtenerDato();

    if (nodo->obtenerDato() == '?' && palabraActual.substr(0, prefijo.size()) == prefijo) {
        palabras.push_back(palabraActual.substr(0, palabraActual.size() - 1));  // Elimina el carácter '?' del final
    }
    

    for (auto& hijo : nodo->obtenerDesc()) {
        buscarPorPrefijo(hijo, prefijo, palabraActual, palabras);
    }
}



bool Sistema::pSufijo(const std::string& sufijo) {
    std::vector<std::string> palabrasConSufijo;
    std::vector<int> longitudes;
    std::vector<int> puntajes;

    // Recorre cada árbol en 'arboles'
    for (auto& arbol : arbolesinverso) {
        if (!arbol.esVacio()) {
            NodoGeneral<char>* raiz = arbol.obtenerRaiz();
            buscarPorSufijo(raiz, sufijo, "", palabrasConSufijo, longitudes, puntajes);
        }
    }

    if (palabrasConSufijo.empty()) {
        std::cout << "Sufijo " << sufijo << " no pudo encontrarse en el diccionario." << std::endl;
        return false;
    }

    // Imprime las palabras que terminan con el sufijo junto con su longitud y puntaje
    std::cout << "Palabras que terminan con '" << sufijo << "':" << std::endl;
    for (size_t i = 0; i < palabrasConSufijo.size(); ++i) {
        std::cout << palabrasConSufijo[i] << " - Longitud: " << longitudes[i] << " - Puntaje: " << puntajes[i] << std::endl;
    }

    return true;
}

void Sistema::buscarPorSufijo(NodoGeneral<char>* nodo, const std::string& sufijo, std::string palabraActual, std::vector<std::string>& palabras, std::vector<int>& longitudes, std::vector<int>& puntajes) {
    if (!nodo) return;

    palabraActual = nodo->obtenerDato() + palabraActual;

    if (nodo->obtenerDato() == '?' && palabraActual.size() >= sufijo.size() && palabraActual.substr(palabraActual.size() - sufijo.size()) == sufijo) {
        std::string palabraSinInterrogante = palabraActual.substr(1); // Quita el primer carácter '?'
        palabras.push_back(palabraSinInterrogante); 

        // Calcular longitud y puntaje de la palabra
        int longitud = palabraSinInterrogante.size(); 
        longitudes.push_back(longitud);

        Palabra p(palabraSinInterrogante); 
        int puntaje = p.calcularPuntaje();
        puntajes.push_back(puntaje);
    }

    // Recorre los descendientes del nodo actual recursivamente
    for (auto& hijo : nodo->obtenerDesc()) {
        buscarPorSufijo(hijo, sufijo, palabraActual, palabras, longitudes, puntajes);
    }
}



bool Sistema::insArbolinverso(const std::string& dato) {
    static int inicializar = 0;
    if (inicializar == 0) {
        // Crear un vector de árboles inversos, cada posición representa una letra del alfabeto
        arbolesinverso.resize(26);

        // Abrir el archivo de texto
        std::ifstream archivo(dato);
        if (!archivo) {
            std::cerr << "El archivo " << dato << " no existe o no puede ser leído." << std::endl;
            return false;
        }

        // Leer y procesar cada palabra del archivo
        std::string palabra;
        while (archivo >> palabra) {
            // Convertir la palabra a minúsculas
            for (size_t i = 0; i < palabra.size(); ++i) {
                palabra[i] = std::tolower(palabra[i]);
            }

            // Verificar si la palabra contiene solo letras del alfabeto
            bool esValida = true;
            for (size_t i = 0; i < palabra.size(); ++i) {
                if (!std::isalpha(palabra[i])) {
                    esValida = false;
                    break;
                }
            }

            // Procesar solo si la palabra es válida
            if (esValida) {
                // Obtener la última letra de la palabra
                char ultimaLetra = palabra[palabra.size() - 1];

                // Calcular el índice correspondiente en el vector de árboles
                int indice = ultimaLetra - 'a';

                // Si el árbol correspondiente no existe, crear uno nuevo con la letra como raíz
                if (arbolesinverso[indice].esVacio()) {
                    NodoGeneral<char>* newRoot = new NodoGeneral<char>;
                    newRoot->fijarDato(ultimaLetra);
                    arbolesinverso[indice].fijarRaiz(newRoot);
                }

                // Agregar la palabra al árbol correspondiente
                char letraPadre = ultimaLetra;
                NodoGeneral<char>* nodoPadre = arbolesinverso[indice].obtenerRaiz();
                for (int i = palabra.size() - 2; i >= 0; --i) { // Insertamos la palabra al revés
                    char letra = palabra[i];
                    nodoPadre = nodoPadre->insertarNodo(letraPadre, letra);
                    letraPadre = letra;
                }

                // Insertar el carácter '?' al final de la palabra
                nodoPadre->insertarNodo(letraPadre, '?');
            } else {
                std::cerr << "La palabra \"" << palabra << "\" contiene caracteres no válidos y no será insertada." << std::endl;
            }
        }

        // Cerrar el archivo
        archivo.close();
        std::cout << "El Arbol de diccionario inverso se ha inicializado correctamente.\n";
        inicializar++;
        std::cout << "Las palabras en el árbol inverso son:\n";
        for (size_t i = 0; i < arbolesinverso.size(); ++i) {
            imprimirPalabras(arbolesinverso[i].obtenerRaiz(), "");
        }

        for (auto& arbol : arbolesinverso) {
        std::cout << "Recorrido preOrden del árbol: ";
        arbol.preOrden();
        std::cout << std::endl;
    }
        return true;
    } else {
        std::cout << "El arbol inverso ya ha sido inicializado.\n";
        return false;
    }
}



void Sistema::imprimirPalabras(NodoGeneral<char>* nodo, std::string palabraActual) {
    if (!nodo) return;

    // Agrega el dato del nodo actual a la palabra actual
    palabraActual += nodo->obtenerDato();

    // Si el nodo actual es el final de una palabra (su dato es '?'), imprime la palabra actual
    if (nodo->obtenerDato() == '?') {
        std::cout << palabraActual << '\n';
    }

    // Recorre los descendientes del nodo actual recursivamente
    for (auto& hijo : nodo->obtenerDesc()) {
        imprimirPalabras(hijo, palabraActual);
    }
}