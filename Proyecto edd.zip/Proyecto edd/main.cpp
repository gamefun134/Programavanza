#include "sistema.h"
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>


int main() {
    std::string linea;
    Sistema sys;

    while (true) {
        std::cout << "\n// Bienvenido al sistema de Scrabble. //\n";
        std::cout << "Los siguientes comandos están disponibles:\n";
        std::cout << "1. inicializar\n";
        std::cout << "2. iniciar_inverso\n";
        std::cout << "3. puntaje\n";
        std::cout << "4. iniciar_arbol\n";
        std::cout << "5. iniciar_arbol_inverso\n";
        std::cout << "6. palabras_por_prefijo\n";
        std::cout << "7. palabras_por_sufijo\n";
        std::cout << "8. grafo_de_palabras\n";
        std::cout << "9. posibles_palabras\n";
        std::cout << "10. salir\n";
        std::cout << "\nEscriba el comando que quiere usar o escriba 'ayuda' para ver la lista de comandos y su uso.\n";
        std::cout << "$ ";

        if (!std::getline(std::cin, linea)) {
            break; 
        }

        std::istringstream iss(linea);
        std::string comando;
        iss >> comando;

        if (comando == "inicializar") {
            std::string archivo;
            iss >> archivo;
            sys.inicializar(archivo);
        } else if (comando == "iniciar_inverso") {
            std::string archivo;
            iss >> archivo;
            sys.inicializarInverso(archivo);
        } else if (comando == "puntaje") {
            std::string palabra;
            iss >> palabra;

            // Convertir la palabra a minúsculas
            for (char& c : palabra) {
                c = std::tolower(c);
            }

            sys.mostrarPuntajePalabra(palabra);
        } else if (comando == "iniciar_arbol") {
            std::string nombreArchivo;
            iss >> nombreArchivo;
            sys.insertarArbol(nombreArchivo);
        } else if (comando == "iniciar_arbol_inverso") {
            std::string nombreArchivo;
            iss >> nombreArchivo;
            sys.insArbolinverso(nombreArchivo);
        } else if (comando == "palabras_por_prefijo") {
            std::string prefijo;
            iss >> prefijo;

            // Convertir el prefijo a minúsculas
            for (char& c : prefijo) {
                c = std::tolower(c);
            }

            sys.pPrefijo(prefijo);
        } else if (comando == "palabras_por_sufijo") {
            std::string sufijo;
            iss >> sufijo;

            // Convertir el sufijo a minúsculas
            for (char& c : sufijo) {
                c = std::tolower(c);
            }

            sys.pSufijo(sufijo);
        } else if (comando == "grafo_de_palabras") {
            // Comando por implementar
        } else if (comando == "posibles_palabras") {
            // Comando por implementar
        } else if (comando == "salir") {
            break;
        } else if (comando == "ayuda") {
            std::cout << "// SISTEMA DE AYUDA //\n";
            std::cout << "inicializar: Inicializa el diccionario a partir del archivo diccionario.txt\n";
            std::cout << "            Uso: inicializar <diccionario.txt>\n";
            std::cout << "iniciar_inverso: Inicializa un diccionario inverso a partir del archivo diccionario.txt\n";
            std::cout << "                 Uso: iniciar_inverso <diccionario.txt>\n";
            std::cout << "puntaje: Obtiene el puntaje de una palabra\n";
            std::cout << "         Uso: puntaje <palabra>\n";
            std::cout << "iniciar_arbol: Inicializa el sistema desde el archivo diccionario.txt almacenando palabras en uno o mas arboles de letras\n";
            std::cout << "               Uso: iniciar_arbol <diccionario.txt>\n";
            std::cout << "iniciar_arbol_inverso: Inicializa el sistema desde el archivo diccionario.txt almacenando palabras en uno o mas arboles de letras en sentido inverso\n";
            std::cout << "                      Uso: iniciar_arbol_inverso <diccionario.txt>\n";
            std::cout << "palabras_por_prefijo: Busca y muestra palabras posibles a construir a partir de un prefijo dado\n";
            std::cout << "                      Uso: palabras_por_prefijo <prefijo>\n";
            std::cout << "palabras_por_sufijo: Busca y muestra palabras posibles a construir que terminan con un sufijo dado\n";
            std::cout << "                     Uso: palabras_por_sufijo <sufijo>\n";
            std::cout << "grafo_de_palabras: Construye un grafo de palabras, conectando palabras que difieren en una unica letra\n";
            std::cout << "                   Uso: construir_grafo_palabras\n";
            std::cout << "posibles_palabras: Genera y muestra en pantalla todas las posibles palabras validas a construir con las letras proporcionadas\n";
            std::cout << "                   Uso: posibles_palabras <letras>\n";
            std::cout << "salir: Termina la ejecucion de la aplicacion\n";
        } else {
            std::cout << "Comando desconocido. Escriba 'ayuda' para ver la lista de comandos y su uso.\n";
        }
    }

    return 0;
}
