#include "ArbolGeneral.h"
#include <queue>

template <class T>
ArbolGeneral<T>::ArbolGeneral()
{
    this->raiz = NULL;
}

template <class T>
ArbolGeneral<T>::ArbolGeneral(const T& val)
{
    NodoGeneral<T>* nodo = new NodoGeneral<T>;
    nodo->fijarDato(val);
    this->raiz = nodo;
}

template <class T>
ArbolGeneral<T>::~ArbolGeneral()
{
    delete this->raiz;
    this->raiz = NULL;
}

template <class T>
bool ArbolGeneral<T>::esVacio()
{
    return this->raiz == NULL;
}

template <class T>
NodoGeneral<T>* ArbolGeneral<T>::obtenerRaiz()
{
    return this->raiz;
}

template <class T>
void ArbolGeneral<T>::fijarRaiz(NodoGeneral<T>* nraiz)
{
    this->raiz = nraiz;
}

template <class T>
bool ArbolGeneral<T>::insertarNodo(T padre, T n)
{
    if (this->esVacio())
    {
        //crear nuevo nodo, asignar datos, poner ese nodo como raiz
        NodoGeneral<T>* nodo = new NodoGeneral<T>;
        nodo->fijarDato(n);
        this->raiz = nodo;

        return true;
    }

    else
    {
        //revisar el nodo donde estoy para ver si coincide con el padre
        if (this->raiz->obtenerDato() == padre)
        {
            //si coincide, insertar el nodo
           return this->raiz->adcionarDesc(n);
        }
        else
        {
            //si no coincide, buscar en los hijos
            return this->raiz->insertarNodo(padre, n);
        }
    }
}

template <class T>
bool ArbolGeneral<T>::eliminarNodo(T n)
{
    typename std::list<NodoGeneral<T>*>::iterator it;
    //si el arbol es vacion solo retornar
    if (this->esVacio())
    {
        return false;
    }

    //si el nodo a eliminar es la raiz
    if (this->raiz->obtenerDato() == n)
    {
        //eliminar la raiz
        delete this->raiz;
        this->raiz = NULL;
        return true;
    }

    bool eliminado = this->raiz->eliminarDesc(n);

    return eliminado;
}

template <class T>
bool ArbolGeneral<T>::buscar(T n)
{
    // Si el árbol está vacío, simplemente retornar false
    if (this->esVacio())
    {
        return false;
    }

    // Llamar a la función auxiliar buscar para buscar el nodo en el árbol
    return raiz->buscar(n);
}

template <class T>
 int ArbolGeneral<T>::altura()
{
    if (this->esVacio())
    {
        return -1;
    }
    else
    {
        return (this->raiz) -> altura();
    }

}

template <class T>
 int ArbolGeneral<T>::tamano()
{
    if (this->esVacio())
    {
        return 0;
    }

    return raiz->tamano();
}

template <class T>
void ArbolGeneral<T>::preOrden()
{
    if (!this->esVacio())
    {
        (this->raiz)->preOrden();
    }
}


template <class T>
void ArbolGeneral<T>::postOrden()
{
    if (!this->esVacio())
    {
        (this->raiz)->postOrden();
    }
}

template <class T>
void ArbolGeneral<T>::nivelOrden()
{
    typename std::list<NodoGeneral<T>*>::iterator it;
    if (!this->esVacio())
    {
        std::queue<NodoGeneral<T>*> cola;
        cola.push(this->raiz);
        while (!cola.empty())
        {
            NodoGeneral<T>* nodo = cola.front();
            cola.pop();
            std::cout << nodo->obtenerDato() << " ";
            typename std::list<NodoGeneral<T>*> desc = nodo->obtenerDesc();
            for (it = desc.begin(); it != desc.end(); it++)
            {
                cola.push(*it);
            }
        }
    }
}